import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='kiran9296',
    application_name='aws-python-flask-api-project',
    app_uid='R8Pz7SvKSp5gfjkD1D',
    org_uid='ef33d4a4-f2e5-41ab-9a4c-aa3e88524e12',
    deployment_uid='7314a200-67d1-4e93-b442-91bf8c28bbaa',
    service_name='aws-python-flask-api-project',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.4.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-python-flask-api-project-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
